<div class="container mt-5 pt-5 d-flex flex-column align-items-center subscribe">
    
    <h4>Subscribe to Our Newsletter</h4>

    <hr class="animate__animated animate__fadeInRight"> 

    <p>Class aptent taciti sociosqu ad litora torquent per conubia nostra. Quisque a vehicula magna.</p>

    <form action="" method="GET" class='d-flex flex-column justify-content-sm-between'>
    
        <input class="email" type="email" placeholder="Email"/>
        <button type="submit">Subscrire</button>

    </form>

</div>

<div class="p-5 ligne">

    <hr>
    
</div>

<div class="container coordonnees">

    <div class="row ml-5 mr-5">

        <div class="col-sm address">
        
            <h4>Address</h4>

            <p>Class aptent taciti sociosqu ad litora torquent per 1230/</p>

        </div>

        <div class="col-sm call_us">
        
            <h4>Call Us</h4>

            <p>(+880)123 456 7898<br/>(+880)123 456 7898</p>
            
        </div>

        <div class="col-sm email_us">
        
            <h4>Email Us</h4>

            <p><a href="mailto:contact@divi.com?subject=Demande%20de%20contact">contact@divi.com</a><br/><a href="mailto:potterystidio@divi.com?subject=Demande%20de%20contact">potterystidio@divi.com</a></p>
            
        </div>
    
    </div>

</div>

<div class="container d-flex justify-content-center row mt-5 mb-5 follow">

    <div class="col-sm p-2">
        <a href=""><img src="images/facebook.png" alt="Pictogramme Facebook"></a>
    </div>

    <div class="col-sm p-2">
        <a href=""><img src="images/twitter.png" alt="Pictogramme Twitter"></a>
    </div>

    <div class="col-sm p-2">
        <a href=""><img src="images/instagram.png" alt="Pictogramme Instagram"></a>
    </div>
    
    <div class="col-sm p-2">
        <a href=""><img src="images/youtube.png" alt="Pictogramme YouTube"></a>
    </div>

</div>

